%Tomasz Indeka
%STP
%projekt 1, zadanie 15

b1 = [1 1.5];
b2 = [1 4.5];

a1 = [1 -7];
a2 = [1 6];
a3 = [1 8];

T = 0.25; % okres pr�bkowania