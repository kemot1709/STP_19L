det([B2 A2*B2 A2^2*B2])
det([C2; C2*A2; C2*A2^2])