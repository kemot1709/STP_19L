clear;
params;
zad1;
zad3;

D = 37/Tp; % horyzont dynamiki obiektu
lambda = 50; % Kara za zmiany sterowania
N = 16; % Dlugosc horyzontu predykcji
Nu = 1; % Dlugosc horyzontu sterowania 
time = 100; % czas trwania symulacji

u(1:11) = 0;
y1(1:12) = 0;
u(13:12+D) = 1;

for k=13:(13+D)
    y1(k)=-Gdyskr.Denominator{1}(2)*y1(k-1)-Gdyskr.Denominator{1}(3)*y1(k-2)+Gdyskr.Numerator{1}(2)*u(k-11)+Gdyskr.Numerator{1}(3)*u(k-12);
    s(k-12)=y1(k);
end

M=zeros(N,Nu);
for i=1:N
   for j=1:Nu
      if (i>=j)
         M(i,j)=s(i-j+1);
      end
   end
end

Mp=zeros(N,D-1);
for i=1:N
   for j=1:D-1
      if i+j<=D
         Mp(i,j)=s(i+j)-s(j);
      else
         Mp(i,j)=s(D)-s(j);
      end     
   end
end

y=zeros(1,time);
uk=zeros(1,time);

psi = eye(N);
lam_up = eye(Nu)*lambda;

K=(M'*psi*M+lam_up)^(-1)*M'*psi;


y_zad(1:N)= 1;
y_zad=y_zad';

yk=zeros(N, 1);
deltau=zeros(1,D-1)';
y0=yk+Mp*deltau;
deltauk=K*(y_zad-y0);
uk= zeros(13,1);

for k=2:time
    if k==2
        y(k)=-Gdyskr.Denominator{1}(2)*y(k-1);
    else
        if k <= 12
            y(k)=-Gdyskr.Denominator{1}(2)*y(k-1)-Gdyskr.Denominator{1}(3)*y(k-2);
        else
            y(k)=-Gdyskr.Denominator{1}(2)*y(k-1)-Gdyskr.Denominator{1}(3)*y(k-2)+Gdyskr.Numerator{1}(2)*uk(k-11)+Gdyskr.Numerator{1}(3)*uk(k-12);
        end
    end
    
    yk=ones(N,1)*y(k);
    y0=yk+Mp*deltau;
    deltauk=K*(y_zad-y0);
    uk(k)=uk(k-1)+deltauk(1);
    deltau=[deltauk(1) deltau(1:end-1)']';
end

stairs( uk, 'g');
hold on;
yzad(1:time) = 1;
stairs(yzad, 'r');
stairs(y, 'b');
title(sprintf('Dzialanie regulatora dla nastaw D = %i, N = %i, Nu = %i, lambda = %i',D,N,Nu,lambda));
legend('Sterowanie', 'Wyj�cie zadane', 'Wyj�cie regulatora', 'Location', 'best');
xlabel('k');
ylabel(sprintf('y(k)\nu(k)'));
% saveas(gcf,sprintf('picture/DMC_%i_%i_%i_%i.png',D,N,Nu,lambda));
hold off;