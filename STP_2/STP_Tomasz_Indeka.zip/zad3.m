clear;
params;
zad1;
Kk = 0.41442; % wyznaczony do�wiadczalnie

stepplot((Kk*Gciagly)/(1+Kk*Gciagly), 10000,'g');
xlabel('t');
ylabel('y(t)');
title('Oscylacje krytyczne obiektu dla d�ugiego czasu obserwacji');
% saveas(gcf,'picture/osc_krytyczne_dlugie.png');

stepplot((Kk*Gciagly)/(1+Kk*Gciagly), 100,'g');
xlabel('t');
ylabel('y(t)');
title('Oscylacje krytyczne obiektu dla kr�tkiego czasu obserwacji');
% saveas(gcf,'picture/osc_krytyczne_krotkie.png');

Tk = 20.04; % odczytane z wykresu
Kr = 0.6 * Kk;
Ti = 0.5 * Tk;
Td = 0.12 * Tk;
r0 = Kr*(Tp/(2*Ti)+Td/Tp+1);
r1 = Kr*(Tp/(2*Ti)-2*(Td/Tp)-1);
r2 = Kr*Td/Tp;
