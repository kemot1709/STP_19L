clear;
x = 1:0.1:2;
% obliczone do�wiadczalnie
y1 = [1.593 1.521 1.455 1.398 1.347 1.298 1.254 1.211 1.172 1.136 1.1];
y2 = [2.042 2.062 2.018 1.94 1.4 0.923 0.645 0.5 0.434 0.418 0.437]; % lambda = 0
y3 = [1.677 1.67 1.647 1.613 1.57 1.525 1.477 1.43 1.382 1.335 1.29];


scatter(x,y1,'bx');
title('Wykres zale�no�ci K0/K0n od T0/T0n dla modelu ze sterowaniem PID');
xlabel('T0/T0n');
ylabel(sprintf('K0/K0n'));
% saveas(gcf,'picture/6_PID_out.png');

scatter(x,y3,'r+');
title('Wykres zale�no�ci K0/K0n od T0/T0n dla modelu ze sterowaniem DMC');
xlabel('T0/T0n');
ylabel(sprintf('K0/K0n'));
% saveas(gcf,'picture/6_DMC_out.png');

scatter(x,y1,'bx');
hold on;
scatter(x,y3,'r+');
ylim([0 2.5]);
title('Wykres zale�no�ci K0/K0n od T0/T0n dla sterowania PID i DMC');
xlabel('T0/T0n');
ylabel(sprintf('K0/K0n'));
legend ('PID','DMC','Location','best');
% saveas(gcf,'picture/6_OUT.png');
scatter(x,y2,'g.');
legend ('PID','DMC','Location','best');
% saveas(gcf,'picture/6_OUT_3.png');
hold off;