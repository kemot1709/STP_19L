clear;
params;
zad1;
zad3;

time=250; % czas symulacji
delay=13; % wynika z konieczno�ci ustabilizowania si� sygna�u steruj�cego, kt�ry potrzebuje danych z pr�bki u(k-12)

% pocz�tkowe warto�ci
u(1:delay)=zeros(1,delay);
y(1:delay)=zeros(1,delay);
e(1:delay)=0;

yzad(1:delay)=zeros(1,delay);
yzad(delay:time)=ones(1,time-delay+1);

for k=delay:time
    y(k)=-Gdyskr.Denominator{1}(2)*y(k-1)-Gdyskr.Denominator{1}(3)*y(k-2)+Gdyskr.Numerator{1}(2)*u(k-11)+Gdyskr.Numerator{1}(3)*u(k-12);
    e(k)=yzad(k)-y(k);
    u(k)=r2*e(k-2)+r1*e(k-1)+r0*e(k)+u(k-1);
end

stairs(u,'g');
title('Wykres sygna�u steruj�cego');
xlabel('k');
ylabel('u(k)');
% saveas(gcf,'picture/PID_in.png');

stairs(yzad,'r');
hold on;
stairs(y,'b');
xlabel('k'); 
ylabel('y(k)');
legend ('Wyj�cie zadane modelu','Wyj�cie modelu','Location','best');
title('Wykres wyj�cia modelu na tle warto�ci zadanej');
% saveas(gcf,'picture/PID_out.png');
hold off;