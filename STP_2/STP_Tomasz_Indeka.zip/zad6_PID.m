clear;
params;
zad1;
zad3;

time=500; % czas symulacji
multiT0 = 2;
multiK0 = 1.1;
delay=10*multiT0 +3; % wynika z konieczno�ci ustabilizowania si� sygna�u steruj�cego, kt�ry potrzebuje danych z pr�bki u(k-12)

% pocz�tkowe warto�ci
u(1:delay)=zeros(1,delay);
y(1:delay)=zeros(1,delay);
e(1:delay)=0;

yzad(1:delay)=zeros(1,delay);
yzad(delay:time)=ones(1,time-delay+1);

for k=delay:time
    y(k)=-Gdyskr.Denominator{1}(2)*y(k-1)-Gdyskr.Denominator{1}(3)*y(k-2)+multiK0*(Gdyskr.Numerator{1}(2)*u(k-delay+2)+Gdyskr.Numerator{1}(3)*u(k-delay+1));
    e(k)=yzad(k)-y(k);
    u(k)=r2*e(k-2)+r1*e(k-1)+r0*e(k)+u(k-1);
end

stairs(u,'g');
hold on;
stairs(yzad,'r');
stairs(y,'b');
xlabel('k'); 
ylabel(sprintf('y(k)\nu(k)'));
legend ('Sterowanie modelu','Wyj�cie zadane modelu','Wyj�cie modelu','Location','best');
title(sprintf('Wykres modelu PID dla T0/T0n = %f i K0/K0n = %f',multiT0,multiK0));
% saveas(gcf,sprintf('picture/6_PID_%f.png',multiT0));
hold off;