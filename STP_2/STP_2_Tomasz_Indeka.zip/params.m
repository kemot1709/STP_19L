% Tomasz Indeka
% 293457
%
% STP projekt 2, zadanie 13

clear;
K = 5.2;
T0 = 5;
T1 = 2.16;
T2 = 4.7;

Tp = 0.5;